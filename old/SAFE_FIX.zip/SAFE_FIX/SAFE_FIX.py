from graphics import *

win = GraphWin("The Safe", 540, 420)

###__IMAGE SHORTCUTS__### :
safe_base = Image(Point(270, 210), "01_safe_plain.gif")
safe_r1 = Image(Point(270, 210), "01_safe_red1.gif")
safe_r2 = Image(Point(270, 210), "01_safe_red2.gif")
safe_r3 = Image(Point(270, 210), "01_safe_red3.gif")
safe_g3 = Image(Point(270, 210), "01_safe_green3.gif")
safe_fail = Image(Point(270, 210), "01_safe_fail.gif")
safe_win = Image(Point(270, 210), "01_safe_win.gif")

inputs = []

def combo():
    
    safe_base.draw(win)
    inputs = []
    combo = [7,3,5]
    clickCounter = 0
    while True:
        p = win.getMouse()
        pX = p.getX()
        pY = p.getY()
        if pX >= 130 and pX <= 224 and pY >= 197 and pY <= 305:
            clickCounter = clickCounter + 1
            print("Click Counter =", clickCounter)
            if clickCounter == 1:
                safe_r1.draw(win)
                
                if pX >= 130 and pX <= 156 and pY >= 279 and pY <= 305:
                    print("7")
                    inputs.append(7)
            elif clickCounter == 2:
                safe_r2.draw(win)
                
                if pX >= 202 and pX <= 224 and pY >= 197 and pY <= 223:
                    print("3")
                    inputs.append(3)
            elif clickCounter == 3:
                safe_r3.draw(win)
                
                if pX >= 165 and pX <= 189 and pY >= 238 and pY <= 263:
                    print("5")
                    inputs.append(5)
                    print(inputs)
                    if inputs == combo:             
                        safe_win.draw(win)
                        if win.getMouse():                                
                            break                   ###__EXIT LOOP TO VIDEO__###
                    else:
                        safe_fail.draw(win)         ###__EXCEPTION = 5__###
                        safe_base.undraw()
                        safe_r1.undraw()
                        safe_r2.undraw()
                        safe_r3.undraw()
                        
                        if win.getMouse():
                            safe_base.draw(win)
                            safe_fail.undraw()
                            clickCounter = 0
                            inputs = []             ###__RINSE AND REPEAT__###
                else:
                    safe_fail.draw(win)
                    safe_base.undraw()
                    safe_r1.undraw()
                    safe_r2.undraw()
                    safe_r3.undraw()
                    
                    if win.getMouse():
                        safe_base.draw(win)
                        safe_fail.undraw()
                        clickCounter = 0
                        inputs = []                 ###__RINSE AND REPEAT__###

    print("cool, you win.")

    ### USE ARMANDOS VIDEO FUNCTION ###
##    frame = []
##    for frame in range(1, 62):
##        fname = "z_"+str(i)+".gif"
##        frame = frame + 1
##
##        
##        
##        SAFE_ANIMATE.append(270, 210)
##        SAFE_ANIMATE.append("z_" + str(k) + ".gif")
##
##    END = [100, CENTER, 'diamond_get.gif']
       


combo()
